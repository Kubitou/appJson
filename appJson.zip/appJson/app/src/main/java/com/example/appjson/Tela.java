package com.example.appjson;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tela extends AppCompatActivity {

    EditText edtJosn, txtLer, txtJsonGer;
    EditText edtNome, edtCll, edtEmail;

    Button btnLerJson, btnTransforma, btnLimpa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    edtNome = findViewById(R.id.inputNome);
    edtCll = findViewById(R.id.inputCell);
    edtEmail = findViewById(R.id.inputEmail);
    edtJosn = findViewById(R.id.containerJson);
    txtLer = findViewById(R.id.containerLer);
    txtJsonGer = findViewById(R.id.containerJsonGerado);
    btnLerJson = findViewById(R.id.btnLerJson);
    btnTransforma = findViewById(R.id.btnGerarJson);
    btnLimpa = findViewById(R.id.btnLimpar);

    }
    public void Limpar(View view){
        edtJosn.setText("");
        edtCll.setText("");
        edtNome.setText("");
        edtEmail.setText("");
        txtJsonGer.setText("");
        txtLer.setText("");
        edtJosn.requestFocus();
    }
    public void LerJson(View v){
        try {
            String strjson = edtJosn.getText().toString();
            JSONObject jsonobj = new JSONObject(strjson);
            txtjsonlido.setText(
                    jsonobj.getString("nome")+" - "+
                            jsonobj.get("celular")+" - "+
                            jsonobj.getString("email")
            );
            ptxtnome.setText(jsonobj.getString("nome"));
            ptxtcelular.setText(jsonobj.getString("celular"));
            ptxtemail.setText(jsonobj.getString("email"));
        }catch (Exception e){
            ptxtjson.setText("Erro ao ler o objeto Json "+ e);
        }
    }
    public void GeraJson(View v){
        try {
            JSONObject objGeraJson = new JSONObject();
            objGeraJson.put("cadnome",ptxtnome.getText().toString());
            objGeraJson.put("cadcelular",ptxtcelular.getText().toString());
            objGeraJson.put("cademail", ptxtemail.getText().toString());
            ptxtjsonfinal.setText(
                    objGeraJson.getString("cadnome")+" - "+
                            objGeraJson.getString("cadcelular"+" - "+
                                    objGeraJson.getString("cademail")+" - ")
            );
        }catch (Exception e){
            ptxtjson.setText("Erro ao ler o objeto Json: "+ e);
        }

    }
}